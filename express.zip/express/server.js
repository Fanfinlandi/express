const e = require('express');
const path = require('path');
const app = e();
app.use(e.static(path.join(__dirname,'public')));
const port =  3000;
app.listen(port,()=>{
        console.log(`localhost:${port}`);
});
